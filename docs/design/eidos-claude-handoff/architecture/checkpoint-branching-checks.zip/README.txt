Local CPU checks used in architecture revision 2, 7 November 2026.

Requires Python 3.12 and PyTorch. Recorded with torch 2.15.0 on CPU,
one thread and deterministic algorithms. No lab runtime is implemented here.

Run: python verify_branching.py
Compare the semantic values with branching-results.json. Exact floating-point
reproduction is environment-specific.

The script checks three new training seeds and a new 4000-pair evaluation draw,
corrects the requested 0.5 percent exception condition through Bernoulli sampling,
checks that a copied weight edit preserves its source, and demonstrates Adam
state sharing with and without a deep copy. switch_order.py and pair_report.py
are the original example modules, included unchanged.

The early and complete models are separate deterministic training runs with the
same seed and data prefix. This is a local scientific fixture, not a test of the
proposed distributed checkpoint service. It does not establish autonomous
scientific superiority, a universal stopping policy or permanent unreachability.
