"""CPU checks behind the architecture's local replication table.

Run beside switch_order.py and pair_report.py, or from the design workspace.
These checks exercise PyTorch mechanics, not an implemented lab service.
"""
import copy
import json
from pathlib import Path
import sys
import torch

HERE = Path(__file__).resolve().parent
if not (HERE / "switch_order.py").exists():
    sys.path.insert(0, str(HERE.parent / "example"))
import switch_order as so
from pair_report import summarize


def main():
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    original_draw, original_steps = so.draw_batch, so.STEPS
    test = original_draw(4000, torch.Generator().manual_seed(76102))

    def both(net):
        return summarize(so.prediction_rows(net, test))["overall"]["both_correct_rate"]

    result = {
        "torch": str(torch.__version__),
        "device": "cpu",
        "evaluation_seed": 76102,
        "evaluation_pairs": 4000,
        "requested_half_percent_rounded_count": round(so.BATCH_SIZE * 0.005),
        "corrected_exception_sampling": [],
        "fresh_seed_replication": [],
    }
    try:
        for seed in (11, 23, 37):
            counts = {"exceptions": 0, "examples": 0}

            def corrected_draw(size, rng):
                batch = original_draw(size, rng)
                mask = torch.rand(size, generator=rng) < 0.005
                recorder = batch.target.clone()
                recorder[mask] = 1 - recorder[mask]
                counts["exceptions"] += int(mask.sum())
                counts["examples"] += size
                return so.Batch(batch.events, recorder, batch.target, batch.pos_a, batch.pos_b)

            so.draw_batch = corrected_draw
            net = so.train(seed, so.OrderedSwitchNet)
            so.draw_batch = original_draw
            result["corrected_exception_sampling"].append({
                "seed": seed, **counts,
                "realized_rate": counts["exceptions"] / counts["examples"],
                "unedited": both(net), "edited": both(so.silence_recorder(net)),
            })

        for seed in (41, 53, 67):
            so.STEPS = 45
            early = so.train(seed, so.OrderedSwitchNet)
            parent_state = copy.deepcopy(early.state_dict())
            edited = so.silence_recorder(early)
            for key, value in early.state_dict().items():
                assert torch.equal(value, parent_state[key]), key
            so.STEPS = 180
            final = so.train(seed, so.OrderedSwitchNet)
            result["fresh_seed_replication"].append({
                "seed": seed, "step_45_unedited": both(early),
                "step_45_edited": both(edited),
                "step_180_unedited": both(final),
                "step_180_edited": both(so.silence_recorder(final)),
                "edit_preserved_parent": True,
            })
    finally:
        so.draw_batch, so.STEPS = original_draw, original_steps

    parent = torch.nn.Linear(2, 1)
    parent_opt = torch.optim.Adam(parent.parameters(), lr=0.01)
    parent(torch.ones(1, 2)).sum().backward()
    parent_opt.step()
    child = copy.deepcopy(parent)
    child_opt = torch.optim.Adam(child.parameters(), lr=0.01)
    p, c = next(parent.parameters()), next(child.parameters())
    child_opt.load_state_dict(parent_opt.state_dict())
    shared = parent_opt.state[p]["exp_avg"].data_ptr() == child_opt.state[c]["exp_avg"].data_ptr()
    child_opt.load_state_dict(copy.deepcopy(parent_opt.state_dict()))
    shared_after_copy = parent_opt.state[p]["exp_avg"].data_ptr() == child_opt.state[c]["exp_avg"].data_ptr()
    result["optimizer_alias"] = {
        "shared_without_deepcopy": shared, "shared_with_deepcopy": shared_after_copy
    }
    assert shared and not shared_after_copy
    return result


if __name__ == "__main__":
    print(json.dumps(main(), indent=2))
