Two small experiments for the research lab design discussion

The fastest way to inspect the finding uses only Python's standard library.
From this directory, run

    python pair_report.py development_pairs.csv

The input holds 1,000 original and switched examples as prediction pairs from the
order-aware model, trained with ordinary loss (seed 11). Each row contains the two
binary decision scores, the two known labels, and the separation category. A score
above zero means class 1. Both-correct counts a pair only if both labels are right.

To reproduce the training experiments, use an environment with PyTorch. I ran
Python 3.12.8 and torch 2.15.0 on CPU with one thread. From this directory, run

    python switch_order.py --save-development-pairs my_pairs.csv
    python image_reuse.py

switch_order.py prints the findings also included in results.json. The same three
initialization/data-stream seeds are used in all four conditions. The fifth condition copies each
ordinary-loss ordered model and sets its recorder coefficient to zero, with no
further training. After this follow-up idea was chosen on development data, all
five conditions were scored on the same fresh 4,000 pairs from the generator. The development
cases used a different data seed. The program also tests strict loading of the
same weights into the two model definitions. It trains its models from scratch.

image_reuse.py prepares a small image classifier, freezes it for an exposure
audit, and calls exactly the same pair_report.summarize function. Its recorded
output is image_results.json. This audit uses two forward calls on 400 image
pairs, and does not update the classifier. Both studies use synthetic data.

These scripts reproduce the model calculations. The proposed lab's package
manager, run isolation, evidence records, and internal LLM are design proposals.
